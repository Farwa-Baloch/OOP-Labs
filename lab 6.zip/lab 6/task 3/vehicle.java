class vehicle {
    String brand;
    int speed;

    void ShowDetails(String brand, int speed) {
        System.out.println("brand: " + brand + " speed: " + speed);
    }
}