public class bike extends vehicle {
    String helmetType;

    void ShowDetails(String name, int speed, String helmetType) {
        super.ShowDetails(name, speed);
        System.out.println("helmet type: " + helmetType);

    }
}
