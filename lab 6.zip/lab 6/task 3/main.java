public class main {
    public static void main(String[] args) {
        car c = new car();
        c.ShowDetails("BMW", 500, 4);
        bike b = new bike();
        b.ShowDetails("tesla", 600, "black");
    }
}
