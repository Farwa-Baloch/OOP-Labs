public class car extends vehicle {
    int numDoors;

    void ShowDetails(String name, int speed, int numDoors) {
        super.ShowDetails(name, speed);

        System.out.println("num of doors: " + numDoors);

    }
}
