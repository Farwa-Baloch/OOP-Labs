public class main {
    public static void main(String[] args) {
        shape sh;
        sh = new circle();
        sh.draw();

        sh = new rectangle();
        sh.draw();
    }
}
