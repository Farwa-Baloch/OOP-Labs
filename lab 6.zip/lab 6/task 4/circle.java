public class circle extends shape {
    @Override
    void draw() {

        System.out.println("drawing a circle");
    }
}
