public class rectangle extends shape {
    @Override
    void draw() {

        System.out.println("drawing a rectangle");
    }
}
