class shape {
    void draw() {
        System.out.println("drawing a shape");
    }
}