public class main {
    public static void main(String[] args) {
        GraduateStudent Gstudent = new GraduateStudent("farwa ", 18, 165, "AI");
        Gstudent.displayInfo();
    }
}
