public class GraduateStudent extends student {
    String researchTopic;

    GraduateStudent(String name, int age, int StudentID, String researchTopic) {
        super(name, age, StudentID);
        this.researchTopic = researchTopic;
    }

    void displayInfo() {
        System.out.println(
                "name: " + super.name + " age: " + super.age + " student ID: " + super.StudentID + " researchTopic: "
                        + researchTopic);
    }
}
