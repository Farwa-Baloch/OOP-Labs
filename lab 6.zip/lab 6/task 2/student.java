public class student extends Person {
    int StudentID;

    student(String name, int age, int StudentID) {
        super(name, age);
        this.StudentID = StudentID;
    }

    void displayInfo() {
        System.out.println("name: " + super.name + " age: " + super.age + " student ID: " + StudentID);
    }
}
