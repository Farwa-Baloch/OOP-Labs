public class main {
    public static void main(String[] args) {
        dog d = new dog();
        d.makeSound();
    }
}
