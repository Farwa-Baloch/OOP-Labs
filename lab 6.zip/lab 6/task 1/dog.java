public class dog extends Animal {
    void makeSound() {
        System.out.println("barking");

    }

}
