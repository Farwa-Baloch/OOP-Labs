class Animal{

    String name;
    int age;
    void makeSound(){
        
    }
    }