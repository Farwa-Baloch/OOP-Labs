import java.util.Scanner;
class task3{
public static void main(String[] args){
int sum=0;
int[][] matrix={
  {12,13,15,16},
  {11,110,121,17},
  {17,18,100,21}
};
for(int i=0;i<3;i++){
  for(int j=0;j<4;j++){
matrix[i][j]=matrix[i][j]/2;
}
}
System.out.println("Printed elements divided by 2: ");
for(int i=0;i<3;i++){
  for(int j=0;j<4;j++){
    System.out.print(matrix[i][j]+" ");
}
System.out.println();
}
System.out.println("odd elements of matrix: ");
for(int i=0;i<3;i++){
  for(int j=0;j<4;j++){
if(matrix[i][j]%2!=0){
    System.out.print(matrix[i][j]+" ");
}
}
System.out.println();
}
for(int i=0;i<3;i++){
  for(int j=0;j<4;j++){
if(matrix[i][j]%2==0){
    sum+=matrix[i][j];
}
}
}
System.out.println("The sum of updated even numbers from the matrix: ");
    System.out.print(sum);

}
}