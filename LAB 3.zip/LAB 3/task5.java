import java.util.Scanner;
class task5{
public static void main(String[] args){


Scanner scanner = new Scanner(System.in);
int rows=4, cols=4;
boolean[][] seats = new boolean[rows][cols];
int choice;
do {
            
System.out.println("1. Display available seats");
System.out.println("2. Reserve a seat");
System.out.println("3. Exit");
System.out.print("Enter your choice: ");
choice = scanner.nextInt();
switch (choice) {
case 1:
  System.out.println("Seat availability:");
for (int i = 0; i < rows; i++) {
  for (int j = 0; j < cols; j++) {
   if (!seats[i][j]) {
  System.out.print("O "); 
    } else {
System.out.print("X "); 
      }
       }
          System.out.println(); 
                       }
 break;
case 2:
  System.out.print("Enter row number (0-" + (rows - 1) + "): ");
  int row = scanner.nextInt();
  System.out.print("Enter column number (0-" + (cols - 1) + "): ");
  int col = scanner.nextInt();
if (row < 0 || row >= rows || col < 0 || col >= cols) {
  System.out.println("Invalid range. Please enter correct row and column.");
  } else if (seats[row][col]) {
 System.out.println("Seat is already reserved.");
  } else {
seats[row][col] = true; 
   System.out.println("Seat reserved successfully.");
  }
  break;
case 3:
  System.out.println("Exiting program...");
  break;
default:
   System.out.println("Invalid choice. Please enter a number between 1 and 3.");
 }
        } while (choice != 3);

      
    }
}