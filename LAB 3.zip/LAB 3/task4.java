import java.util.Scanner;
class task4{
public static void main(String[] args){

int i=0;

int[] arr=new int [10];
do{
   arr[i]=(i+1)*(i+1);
i++;
}while(i<arr.length);
arr[9]=0;
 System.out.print("Square numbers: ");
        for (int num=0;num<arr.length;num++ ) {
            System.out.print(arr[num]+ " ");
        }
        System.out.println();
int j=0;
int sum=0;
while(j<arr.length){
   if(arr[j]==81){
     break;
} 
    if(j%2!=0){
       sum+=arr[j];
}
j++;       
}
System.out.print("SUM OF ODD NUMBERS FROM THE ARRAY: "+sum);

}
}