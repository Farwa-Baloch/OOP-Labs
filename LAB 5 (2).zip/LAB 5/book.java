//TASK 1:
class book{
    String title;
    String author;
    boolean isAvailable;
    book(String title,String author){
        this.title=title;
        this.author=author;
        this.isAvailable=true;
    }
    public void borrowBook(){
                    isAvailable=true;

        if(isAvailable){
                        isAvailable=false;

                System.out.println("you successfully borrowed the book.");

        }else{
            System.out.println("book is already borrowd.");
        }

     }
        
    
    public void returnBook(){
      isAvailable=true;
      System.out.println("you have successfully returned the book.");
    }
    public void displayBookDetails() {
        String status = isAvailable ? "Available" : "Not Available";
        System.out.println(status);
        
    }
    public static void main(String[] args){
        book b1=new book("it ends with us","Collen hoover");
        b1.displayBookDetails();
        b1.borrowBook();
        b1.displayBookDetails();

                    b1.borrowBook();
                    b1.returnBook();
                    b1.displayBookDetails();

    }

}