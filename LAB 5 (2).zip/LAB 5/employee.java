// TASK 2:
class employee{
    String name;
   int empID;
   int salary;
   employee(String name,int empID,int  salary){
    this.name=name;
    this.empID=empID;
    this.salary=salary;
   }
   public void increaseSalary(int amount){
if(amount>0){
    salary+=amount;
System.out.println("employee's  increased salary is: "+salary);
}else{
    System.out.println("invalid amount!!");
}
   }
   
   public int calculateAnnualSalary(){
 return salary*12;

   }
   public void displayDetails(){
    System.out.println("NAME: "+name);
    System.out.println("EMPLOYEE ID: "+empID);
    System.out.println("EMPLOYEE'S CURRUNT SALARY  IS; "+salary);

   }
   

    public static void main(String[] args){
        employee b1=new employee("Farwa",165,700000);
        b1.increaseSalary(2000);
        b1.displayDetails();
        System.out.println("employee's annual salary is: "+b1.calculateAnnualSalary());

    }
}