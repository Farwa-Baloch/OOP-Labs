
package chatting_application;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import javax.swing.*; // javax ---extended pkg of java
import javax.swing.border.EmptyBorder;
import java.net.*;


public class Server  extends JFrame implements ActionListener{

    JTextField text;
    JPanel text_area;
    static Box verticle = Box.createVerticalBox();// for line by line msgs
    static JFrame f = new JFrame();
    static DataOutputStream sendmsg;
    Server(){
        
      f.setLayout(null);
    
      
      
      
      // HEADER PANEL 
      JPanel header=new JPanel();
      header.setBackground(new Color(7,94,84));
      header.setBounds(0,0,450,70);
      header.setLayout(null);
      f.add(header);
      
 
       JLabel profilePic = new JLabel("👤"); // Using emoji as profile picture
        profilePic.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 30));
        profilePic.setBounds(10, 15, 40, 40);
        profilePic.setForeground(Color.WHITE);
        header.add(profilePic);
      
      //   NAME
      JLabel name=new JLabel("Alex");
      name.setBounds(50,20,100,18);
      name.setForeground(Color.WHITE);
      name.setFont(new Font("SAN SERIF",Font.BOLD,24));
      header.add(name);
      
     //text Area 
      text_area=new JPanel();
      text_area.setBounds(3,74,430,440);
     f.add(text_area);
     
     
     // Bottom panel for text input
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(255, 255, 255));
        bottomPanel.setBounds(0, 510, 450, 70);
        bottomPanel.setLayout(null);
        f.add(bottomPanel);
        
     // Text field for message input
        text = new JTextField();
        text.setBounds(5, 5, 350, 40);
        text.setFont(new Font("SAN SERIF", Font.PLAIN, 16));
        bottomPanel.add(text);
           
        
        // BUTTON
      JButton sendButton = new JButton("Send");
        sendButton.setBounds(360, 5, 80, 40);
        sendButton.setBackground(new Color(7, 94, 84));
        sendButton.setForeground(Color.WHITE);
        sendButton.addActionListener(this);
        sendButton.setFont(new Font("SAN SERIF", Font.PLAIN, 16));
        bottomPanel.add(sendButton);
      
        
        
        
    f.setSize(450,600);
    f.setLocation(200,50);//to open a frame 
  f.getContentPane().setBackground(Color.WHITE);
    f.setVisible(true);

    }
    public void actionPerformed(ActionEvent ae){
        try{
            String str = text.getText();

            JPanel p = formatLabel(str);

            System.out.println(str);
            text_area.setLayout(new BorderLayout());
            JPanel right = new JPanel(new BorderLayout());
            right.add(p, BorderLayout.LINE_END);
            verticle.add(right);
            verticle.add(Box.createVerticalStrut(15));// spaces between text is 15
            text.setText("");
            text_area.add(verticle, BorderLayout.PAGE_START);
            sendmsg.writeUTF(str);
            f.repaint();
            f.invalidate();
            f.validate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static JPanel formatLabel(String str){
    JPanel panel=new JPanel();
    panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
    JLabel output=new JLabel(str);
    output.setFont(new Font("Tahoma",Font.BOLD,16));
    output.setBackground(Color.green);
    output.setOpaque(true);
    output.setBorder(new EmptyBorder(15,15,15,50));// to add padding
    panel.add(output);
    
    
    return panel;
    }
    public static void main(String[] args){
        new Server();// anonymous object 
        try {
            ServerSocket skt = new ServerSocket(6001);
            while (true) {
                Socket s = skt.accept();
                DataInputStream rcvMsg = new DataInputStream(s.getInputStream());
                sendmsg = new DataOutputStream(s.getOutputStream());

                //to read msgs infintly we use a protocol ---writeUTF
                while (true) {
                    String msg = rcvMsg.readUTF();
                    JPanel panel = formatLabel(msg);
                    JPanel left = new JPanel(new BorderLayout());
                    left.add(panel, BorderLayout.PAGE_END);
                    verticle.add(left);
                    f.validate();

                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
}
    }
