import java.util.Scanner;
class lab7{
	public static void main(String[] args) {
		//task 1:

	// Scanner scan=new Scanner(System.in);
	// System.out.println("enter the string: ");
	// String name=scan.nextLine();
	// if(name.isEmpty()){
	// 	System.out.println("string is empty");

	// }	else{
	// 	System.out.println("string is not empty");
	// }





		//task 2:
// Scanner scan=new Scanner(System.in);
// 	System.out.println("enter the string: ");
// 	String str=scan.nextLine();
//  int index = str.indexOf("a");
        
      
//         System.out.println("Index of first occurrence of a: " + index);




         //task 3:

// Scanner scan=new Scanner(System.in);
// String[] array=new String[5];
// 	System.out.println("enter 5 strings: ");

// for(int i=0;i<5;i++){
//       array[i]=scan.nextLine();
// }

// for(int i=0;i<5;i++){
//       array[i]=array[i].toUpperCase();
// }
// for(int i=0;i<5;i++){
//       System.out.print(array[i]+" ");
// }




          //task 4:

	// 	Scanner scan=new Scanner(System.in);
	// System.out.println("enter the string: ");
	// String str=scan.nextLine();
	// if(str.startsWith("hello")){
	// 	System.out.println("string starts with hello ");
	// }else{
	// 	System.out.println("string does not start with hello ");
	// }




		//task 5;


	// 		Scanner scan=new Scanner(System.in);
	// System.out.println("enter the string: ");
	// String str=scan.nextLine();
	// if(str.endsWith("world")){
	// 	System.out.println("string ends with world");
	// }else{
	// 	System.out.println("string does not end with world ");
	// }




             
              //task 6

// Scanner scan=new Scanner(System.in);
// 	System.out.println("enter the string: ");
// 	String str=scan.nextLine();
// 	if(str.contains("java")){
// 		System.out.println("string contains java");
// 	}else{
// 		System.out.println("string does not contain java");
// 	}






		//task 7
// Scanner scan=new Scanner(System.in);
// 	System.out.println("enter the string: ");
// 	String str=scan.nextLine();


// 	String modified=str.replace(" ","");
// 	System.out.println(modified);




		//task 8:
		Scanner scan=new Scanner(System.in);
 	System.out.println("enter the string: ");
 	 	String str=scan.nextLine();
 String[] words = str.split(" ");
        
        int wordCount = 0;
        for (String word : words) {
            
                System.out.println(word);
                wordCount++;
            }
        
        
        System.out.println("Total words: " + wordCount); 
        
        









}


	}
