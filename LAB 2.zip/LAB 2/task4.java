import java.util.Scanner;
class task4{
    public static void main(String[] args){
        String[] StringArray=new String[6];

 Scanner scanner = new Scanner(System.in);
 System.out.println("Enter 6 names:");
for(int i=0;i<6;i++){
System.out.println("Enter the name for["+ i +"]: ");
     StringArray[i]=scanner.nextLine();
}
boolean found=false;
for (String name: StringArray){
   if(name.equalsIgnoreCase("Ali")){
       found=true;
break;
}
}
 if (found) {
 System.out.println("The name 'Ali' is present in the array.");
  } else {
 System.out.println("The name 'Ali' is not present in the array.");
        }
    }
}