import java.util.Scanner;
class task6{
    public static void main(String[] args){
Scanner scan=new Scanner(System.in);
System.out.println("Enter the age: ");
int age=scan.nextInt();
String result=(age>=18)?"you are eligible!":"sorry! you are not eligible :(";
System.out.println(result);


    }
}