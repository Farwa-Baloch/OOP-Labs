import java.util.Scanner;
class task5{
    public static void main(String[] args){
Scanner scan=new Scanner(System.in);
int[][] matrix=new int[4][5];
System.out.println("enter the elements of matrix : ");
for(int i=0;i<4;i++){
for(int j=0;j<5;j++){
    System.out.print("enter the value for ["+ i +"]"+"["+ j +"]: ");
    matrix[i][j]=scan.nextInt();
}
}
System.out.println("Printed elements of matrix : ");
for(int i=0;i<4;i++){
for(int j=0;j<5;j++){
    System.out.print(matrix[i][j]+" ");
}
System.out.println();
}
 boolean  found= false;
 for (int i = 0; i < matrix.length; i++) {
 if (matrix[i][0]==1&&matrix[i][matrix[0].length - 1]==1&&matrix[i][i]== 1) {
 found= true;
break;
    }
  }
if (found) {
  System.out.println("The letter 'N' is present");
 } else {
    System.out.println("The letter 'N' is not present");
  }


    
    }
}