import java.util.Scanner;
class task7{
    public static void main(String[] args){

        int[] array={12,34,56,78,34,23};
int smallest=array[0];
int largest=array[0];
for(int i=0;i<array.length;i++){
      if (array[i] < smallest) {
                smallest = array[i];
            }
            if (array[i] > largest) {
                largest = array[i];
            }
}
 System.out.println("Smallest element: " + smallest);
 System.out.println("Largest element: " + largest);
if(largest%2==0){
System.out.println("largest number is a multiple of 2");

}else {
System.out.println(" largest number is not a multiple of 2");
}

    }
}
