import java.util.Scanner;
class task1{
    public static void main(String[] args){
 Scanner obj=new Scanner(System.in);
        char[]  const_arr={'b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','z',
        'B','C','D','F','G','H','J','K','L','M','N','P','Q','Y','X','W','V','W','X','Z'};
        System.out.println("enter the character: ");
        char user_input=obj.next().charAt(0);
        for(char c: const_arr){
        if(c==user_input){
            System.out.println("character is present!");

        }
        }
    }
    }