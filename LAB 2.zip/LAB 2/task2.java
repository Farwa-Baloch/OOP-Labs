import java.util.Scanner;
class task2{
    public static void main(String[] args){

    Scanner obj=new Scanner(System.in);
int array[]=new int[10];
System.out.print("enter the elements of array: ");
for(int i=0; i<10;i++){
   array[i]=obj.nextInt();

}
System.out.print("printed elements: ");
   for(int i=0; i<10;i++){
   System.out.print(array[i]+" ");
   
}
System.out.println();
int sum = 0;
        System.out.println("Multiples of 4 in the array:");
        for (int num : array) {
            if (num % 4 == 0) {
                System.out.print(num + " ");
                sum += num;
            }
        }

    
    
    
    }}