class task6 {

    public static void main(String[] args) {
        int[] count = new int[21];

        int number = 0;
        for (int i = 0; i < 100; i++) {
            count[number]++;

            number++;

            if (number > 20) {
                number = 0;
            }
        }

        for (int i = 0; i < count.length; i++) {
            System.out.println("Number " + i + ": " + count[i] + " times");
        }
    }
}
