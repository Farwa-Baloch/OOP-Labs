class task3 {
    static boolean isUnique(String str) {
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);

            for (int j = i + 1; j < str.length(); j++) {
                if (c == str.charAt(j)) {
                    return false;
                }
            }
        }
        return true;
    }

    static int longestUniqueSubstring(String str) {
        int maxLength = 0;

        for (int i = 0; i < str.length(); i++) {
            for (int j = i + 1; j <= str.length(); j++) {
                String sub = str.substring(i, j);

                if (isUnique(sub)) {
                    if (sub.length() > maxLength) {
                        maxLength = sub.length();
                    }
                }
            }
        }

        return maxLength;
    }

    public static void main(String[] args) {
        String input = "abcabcbb";
        int result = longestUniqueSubstring(input);
        System.out.println("Longest unique substring length: " + result);
    }
}
