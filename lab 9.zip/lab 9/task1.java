public class task1 {
    String rev = "";

    String reversingString(String str) {
        for (int i = str.length() - 1; i >= 0; i--) {
            rev += str.charAt(i);
        }
        return rev;

    }

    public static void main(String[] args) {
        task1 obj = new task1();
        System.err.println(obj.reversingString("hello"));
    }
}
