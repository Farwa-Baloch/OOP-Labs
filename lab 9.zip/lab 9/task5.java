import java.util.Scanner;

class task5 {
    static boolean isPrime(int num) {
        if (num < 2)
            return false;

        for (int i = 2; i < num; i++) {
            if (num % i == 0)
                return false;
        }

        return true;
    }

    static void generatePrimeByIndex(int min, int max) {
        int[] primes = new int[max - min + 1];
        int count = 0;

        for (int i = min; i <= max; i++) {
            if (isPrime(i)) {
                primes[count] = i;
                count++;
            }
        }

        if (count == 0) {
            System.out.println("No prime numbers found in this range.");
            return;
        }
        System.out.println("Prime numbers between " + min + " and " + max + ":");
        for (int i = 0; i < count; i++) {
            System.out.println("Index " + i + ": " + primes[i]);
        }

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter an index to pick a prime: ");
        int index = sc.nextInt();

        if (index >= 0 && index < count) {
            System.out.println("Selected prime: " + primes[index]);
        } else {
            System.out.println("Invalid index.");
        }
    }

    public static void main(String[] args) {
        int min = 10;
        int max = 20;

        generatePrimeByIndex(min, max);
    }
}
