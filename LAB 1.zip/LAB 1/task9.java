import java.util.Scanner;
class task9{
       public static void main(String[] args){ 




System.out.println("\t---CALCULATER---\t");
Scanner obj=new Scanner(System.in);
System.out.print("Enter the 1st number: ");
int n1=obj.nextInt();
System.out.print("Enter the 2nd number: ");
int n2=obj.nextInt();

System.out.println("which operation do you want perform: ('+','-','*','%')");
char choice=obj.next().charAt(0);
switch (choice){
  case '+':
  System.out.println(n1+"+"+n2+"="+(n1+n2));
break;
case '-':
 System.out.println(n1+"-"+n2+"="+(n1-n2));
break;
case '*':
 System.out.println(n1+"*"+n2+"="+(n1*n2));
break;
case '%':
 System.out.println(n1+"%"+n2+"="+(n1%n2));
break;

}
}
}