import java.util.Scanner;
class Task1{
       public static void main(String[] args){ 

    System.out.println("\t ///////\\\\\\\\\\");
    System.out.println("\tStudents points");
    System.out.println("\t \\\\\\///////////");
    System.out.println("\tlabs \t bonus \t total");
    System.out.println("\t-------\t-------\t-------");
    System.out.println("\t43 \t   7 \t     50");
    System.out.println("\t50 \t   8 \t     58");
    System.out.println("\t39 \t   10\t     49");
}
}