import java.util.Scanner;
class task7{
       public static void main(String[] args){ 


Scanner obj=new Scanner(System.in);
System.out.print("Enter the radius of cylinder: ");
int r=obj.nextInt();
System.out.print("Enter the height of cylinder: ");
int h=obj.nextInt();

double pi=3.14;
double converting=pi*r*r*h;
System.out.print("Volume of cylinder is: "+converting);










}


}