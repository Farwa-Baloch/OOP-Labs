import java.util.Scanner;
class task8{
       public static void main(String[] args){ 



Scanner obj=new Scanner(System.in);
System.out.print("Enter SPEED IN MILES: ");
int miles=obj.nextInt();
double converting=miles*1.609;
System.out.print("Equivalent speed (in miles per hour) into kilometer per hour: "+converting);



}
}