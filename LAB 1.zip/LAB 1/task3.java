import java.util.Scanner;
class task3{
       public static void main(String[] args){ 
System.out.println("\t--------STUDENT DATABASE--------\t");
String name="Umm e farwa";
int age=18;
char grade='A';
double GPA=3.47;
char gender ='F';
String foreigner="NOt";
int studentID=165;
System.out.println("the name of student is: "+name);
System.out.println("the age of student: "+age);
System.out.println("grade point of student: "+GPA);
System.out.println("gender of student: "+gender);
System.out.println("is student foreigner or not? "+foreigner);
System.out.println("id of student: "+studentID);
}
}