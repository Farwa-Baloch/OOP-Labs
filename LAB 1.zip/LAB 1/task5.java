import java.util.Scanner;
class task5{
       public static void main(String[] args){ 



System.out.println("\t*********");
System.out.println("\t*\t*");
System.out.println("\t*\t*");
System.out.println("\t*\t*");
System.out.println("\t*\t*");
System.out.println("\t*********");
}

}