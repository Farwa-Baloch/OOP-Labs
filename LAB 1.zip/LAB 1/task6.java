import java.util.Scanner;
class task6{
       public static void main(String[] args){ 

 Scanner obj=new Scanner(System.in);
System.out.println("\t---CURRENCY CONVERTING FROM DOLLARS TO PAKISTANI RUPEES---\t");
System.out.print("Enter the value in Dollars: ");
int dollar=obj.nextInt();
double converting=dollar*277.53;
System.out.println("Value in rupees: "+converting);



}
}