class Car implements Vehicle {
    public void start() {
        System.out.println("car started");
    }

    public void stop() {
        System.out.println("car stopped");
    }

}
