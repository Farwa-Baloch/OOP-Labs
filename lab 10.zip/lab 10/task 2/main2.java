class main2 {
    public static void main(String[] args) {
        Car c = new Car();
        Bike b = new Bike();
        c.start();
        c.stop();
        b.start();
        b.stop();
    }
}
