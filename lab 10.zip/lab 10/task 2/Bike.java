class Bike implements Vehicle {
    public void start() {
        System.out.println("bike started");
    }

    public void stop() {
        System.out.println("bike stopped");
    }

}
