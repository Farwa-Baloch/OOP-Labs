abstract class Employeee {
    String name;
    String id;

    abstract void calculateSalary();
}
