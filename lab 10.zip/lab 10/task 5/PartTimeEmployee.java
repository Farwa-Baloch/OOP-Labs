class PartTimeEmployee extends Employeee implements TaxPayer {
    public void calculateSalary() {
        int PerHourSalary = 1000;
        int SixteenHoursSalary = 16 * 1000;
        System.out.println("total salary per hour: " + SixteenHoursSalary);
    }

    public void payText() {
        double result = (10.0 / 100.0) * (16 * 1000);
        System.out.println(" pay text: " + result);
    }
}
