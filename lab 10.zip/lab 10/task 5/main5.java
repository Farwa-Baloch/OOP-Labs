class main5 {
    public static void main(String[] args) {
        PartTimeEmployee p = new PartTimeEmployee();
        p.calculateSalary();
        p.payText();
        FullTimeEmployee f = new FullTimeEmployee();
        f.calculateSalary();
        f.payText();
    }
}
