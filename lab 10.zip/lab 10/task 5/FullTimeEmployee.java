class FullTimeEmployee extends Employeee implements TaxPayer {
    public void calculateSalary() {
        int fixedSalary = 450000;
        System.out.println("fixed salary: " + fixedSalary);
    }

    public void payText() {
        double result = ((10.0 / 100.0) * 450000.0);
        System.out.println(" pay text: " + re              sult);
    }

}
