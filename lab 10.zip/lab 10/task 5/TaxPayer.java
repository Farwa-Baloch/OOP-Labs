interface TaxPayer {
    void payText();
}
