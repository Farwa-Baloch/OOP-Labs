class Duck implements flyable, swimmable {
    public void fly() {
        System.out.println("duck can not fly");
    }

    public void swimm() {
        System.out.println("duck swims");
    }
}
