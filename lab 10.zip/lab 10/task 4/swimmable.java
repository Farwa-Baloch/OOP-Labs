interface swimmable {
    void swimm();
}
