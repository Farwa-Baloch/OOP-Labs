interface flyable {
    void fly();

}
