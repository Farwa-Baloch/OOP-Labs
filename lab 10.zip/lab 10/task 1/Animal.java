abstract class Animal {
    abstract void makeSound();

    void eat() {
        System.out.println("animal is eating");
    }
}