class main3 {
    public static void main(String[] args) {
        rectangle r = new rectangle();
        r.print();
        System.out.println(r.area(2, 4));

    }
}
