interface printable {
    void print();
}
