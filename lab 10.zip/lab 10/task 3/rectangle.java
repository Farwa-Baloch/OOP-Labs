class rectangle extends Shape implements printable {
    public void print() {
        System.out.println("area of rectangle: ");
    }

    public double area(int w, int l) {
        return w * l;
    }

}