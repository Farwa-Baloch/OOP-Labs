public class Temprature {
    private double celcius;
    private double Fahrenheit;

    void setCelcius(double celcius) {
        this.celcius = celcius;
    }

    double getFahrenheit() {
        return (Fahrenheit = celcius * 9 / 5 + 32);
    }

    public static void main(String[] args) {
        Temprature temp = new Temprature();
        temp.setCelcius(25.5);
        System.out.println("Fahrenheit:" + temp.getFahrenheit());

    }
}
