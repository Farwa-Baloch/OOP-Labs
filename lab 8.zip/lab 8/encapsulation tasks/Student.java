class Student {
    private String name;
    private String rollNum;
    private char grade;

    void setName(String name) {
        this.name = name;
    }

    void setrollNum(String rollNum) {
        this.rollNum = rollNum;
    }

    void setGrade(char grade) {
        this.grade = grade;
    }

    String getName() {
        return name;
    }

    String getrollNum() {
        return rollNum;
    }

    char getGrade() {
        return grade;
    }

    void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Roll number: " + rollNum);
        System.out.println("Grade: " + grade);
    }

    public static void main(String[] args) {
        Student student = new Student();
        student.setName("farwa");
        student.setrollNum("101");
        student.setGrade('A');
        student.displayInfo();
    }
}