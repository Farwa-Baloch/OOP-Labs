class Employee{
	double calculateBonus(int salary){
		return ((10*salary)/100);
	}
	double calculateBonus(int salary, int extraHours){
		return (((10*salary)/100)+(extraHours*500));
	}
	public static void main(String[] args) {
		Employee emp = new Employee();
		System.out.print("10% of salary is: ");
System.out.println(emp.calculateBonus(50000)); 

System.out.println(emp.calculateBonus(50000, 3));
	}
}