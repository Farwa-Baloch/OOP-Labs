public class Dog extends Animal {
    void makeSound() {
        System.out.println("dog barks");
    }
}
