public class Cat extends Animal {
    void makeSound() {
        System.out.println("cat meows");
    }

}
