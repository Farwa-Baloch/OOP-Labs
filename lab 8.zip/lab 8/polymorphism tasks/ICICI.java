public class ICICI extends Bank {
    double getInterestRate() {
        return 7.5;
    }

}
