public class SBI extends Bank {
    double getInterestRate() {
        return 8.5;
    }
}
