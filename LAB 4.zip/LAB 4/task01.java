class task01{
    double radius;
    String color;
    public void calculateArea(){
        double area=(3.14)*radius*radius;
        System.out.println("arae of circle: "+area);
    }
    public static void main(String[] args){
        task01 red_circle=new task01();
        task01 green_circle=new task01();
         
         red_circle.radius=9.9;
          red_circle.color="red";
           green_circle.radius=44.8;
          green_circle.color="green";
           
red_circle.calculateArea();
green_circle.calculateArea();


System.out.println("radius of red circle: "+red_circle.radius);

System.out.println("radius of red circle: "+green_circle.radius);

    }
}