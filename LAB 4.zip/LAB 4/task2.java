class task2{
    double radius;
    String color;
     task2(double radius,String color){
        this.radius=radius;
        this.color=color;
     }
    public double calculateArea(){
        double area=(3.14)*radius*radius;
        return area;
    }
    public static void main(String[] args){
        task2 red_circle=new task2(9.9,"red");
        task2 green_circle=new task2(44.8,"green");


System.out.println("radius of red circle: "+red_circle.radius);

System.out.println("radius of green circle: "+green_circle.radius);

System.out.println("Area of Red Circle: " + red_circle.calculateArea());
System.out.println("Area of Green Circle: " + green_circle.calculateArea());
    }
}