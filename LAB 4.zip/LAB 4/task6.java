class task6 {
    int rows;
    int cols;
    int[][] matx; 
    task6(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        matx = new int[rows][cols]; 
    }
    void get_matrix() {
        System.out.println("Matrix:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(matx[i][j] + " ");
            }
            System.out.println();
        }
    }
    void set_element(int row, int col, int value) {
        if (row >= 0 && row < rows && col >= 0 && col < cols) {
            matx[row][col] = value;
        } else {
            System.out.println("Invalid index!");
        }
    }

    public static void main(String[] args) {
        task6 matrix1 = new task6(4, 3); 
        task6 matrix2 = new task6(3, 3); 
        matrix1.set_element(0, 0, 1);
        matrix1.set_element(0, 1, 2);
        matrix1.set_element(0, 2, 3);
        matrix1.set_element(1, 0, 4);
        matrix1.set_element(1, 1, 5);
        matrix1.set_element(1, 2, 6);
        matrix1.set_element(2, 0, 7);
        matrix1.set_element(2, 1, 8);
        matrix1.set_element(2, 2, 9);
        matrix1.set_element(3, 0, 10);
        matrix1.set_element(3, 1, 11);
        matrix1.set_element(3, 2, 12);

        matrix2.set_element(0, 0, 1);
        matrix2.set_element(0, 1, 2);
        matrix2.set_element(0, 2, 3);
        matrix2.set_element(1, 0, 4);
        matrix2.set_element(1, 1, 5);
        matrix2.set_element(1, 2, 6);
        matrix2.set_element(2, 0, 7);
        matrix2.set_element(2, 1, 8);
        matrix2.set_element(2, 2, 9);

        matrix1.set_element(1, 2, 3);//updating

        System.out.println("Matrix 1:");
        matrix1.get_matrix();
        
        System.out.println("Matrix 2:");
        matrix2.get_matrix();
    }
}
