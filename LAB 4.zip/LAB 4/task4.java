class task4{
    String name;
     int yearOfJoining;
     String address;
    task4(String name, int yearOfJoining, String address) {
        this.name = name;
        this.yearOfJoining = yearOfJoining;
        this.address = address;
    }
    public void displayInfo() {
        System.out.println(name+" "+yearOfJoining+" "+address+" ");
    }


    public static void main(String[] args) {
        task4 emp1 = new task4("\tRobert\t", 1994, "\tWallsStreat");
        task4 emp2 = new task4("\tSam\t", 2000, "\tWallsStreat");
        task4 emp3 = new task4("\tJohn\t", 1999, "\tWallsStreat");
        System.out.println("\tName\t yearOfJoining\t address\t");
        System.out.println("------------------------------");

    emp1.displayInfo();
    emp2.displayInfo();
      emp3.displayInfo();

    }
    

}