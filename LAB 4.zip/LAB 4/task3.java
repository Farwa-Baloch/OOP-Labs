class task3{
    int balance;
    String AccountNumber;
    task3(int balance,String AccountNumber){
        this.balance=balance;
        this.AccountNumber=AccountNumber;
    }
     
    public void deposit(int amount){
        if(amount>0){
            balance+=amount;
            System.out.println("Deposited " + amount + " into account " + AccountNumber);
        }else{
         System.out.println("invalid amount");

        }

    } 
    public void withdraw(int amount){
if(amount>0&&amount<=balance){
            balance+=amount;
            System.out.println("Withdrawn " + amount + " from account " + AccountNumber);
        }else{
         System.out.println("Insufficient amount");

        }
    }
    public void checkbalance(){
System.out.println("Account " + AccountNumber + " balance: " + balance);
    }
   
    public static void main(String[] args){
        task3 acc1=new task3(1000,"1");
        task3 acc2=new task3(500,"2");

acc1.checkbalance();
acc2.checkbalance();

   acc1.deposit(500);
 acc2.deposit(1500);
    
acc1.checkbalance();
acc2.checkbalance();

acc1.withdraw(500);
acc1.checkbalance();


acc2.withdraw(3000);




    }
}